
import React, { useState } from 'react';
import { authApi } from '../api';
import { UserRole } from '../types';
import { ShieldCheck, Globe } from 'lucide-react';

interface LoginScreenProps {
  onLogin: (token: string, user: any) => void;
}

const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin }) => {
  const [isRegister, setIsRegister] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [role, setRole] = useState<UserRole>(UserRole.BUYER);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    
    try {
      if (isRegister) {
        const res = await authApi.register({ email, password, name, role });
        onLogin(res.token, res.user);
      } else {
        const res = await authApi.login({ email, password });
        onLogin(res.token, res.user);
      }
    } catch (err: any) {
      setError(err.message || 'Authentication failed. Please verify credentials.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-white flex flex-col max-w-lg mx-auto overflow-hidden">
      <div className="flex-1 flex flex-col px-8 pt-16 pb-8">
        <div className="mb-12 flex flex-col items-center">
          <div className="w-16 h-16 bg-red-600 rounded-2xl flex items-center justify-center text-white mb-6 shadow-xl shadow-red-100">
            <Globe size={32} />
          </div>
          <h1 className="text-3xl font-black text-gray-900 tracking-tighter uppercase italic">XB2BX</h1>
          <p className="text-gray-400 font-bold tracking-[0.3em] text-[10px] uppercase mt-1">Cross-Border Business</p>
        </div>

        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900">
            {isRegister ? 'Business Registration' : 'Partner Portal'}
          </h2>
          <p className="text-gray-500 text-sm mt-1">
            {isRegister ? 'Join the global network of verified traders.' : 'Access your global trade dashboard.'}
          </p>
        </div>

        {error && (
          <div className="bg-red-50 border-l-4 border-red-600 text-red-700 p-4 rounded-r-xl mb-6 text-xs font-medium flex items-center">
            <span className="mr-2">⚠️</span> {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-5">
          {isRegister && (
            <div>
              <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5 ml-1">Company / Full Name</label>
              <input 
                type="text" 
                required
                className="w-full px-5 py-4 bg-gray-50 border border-gray-100 rounded-2xl focus:bg-white focus:ring-2 focus:ring-red-600/10 focus:border-red-600 focus:outline-none transition-all text-sm font-medium"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Business entity name"
              />
            </div>
          )}

          <div>
            <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5 ml-1">Corporate Email</label>
            <input 
              type="email" 
              required
              className="w-full px-5 py-4 bg-gray-50 border border-gray-100 rounded-2xl focus:bg-white focus:ring-2 focus:ring-red-600/10 focus:border-red-600 focus:outline-none transition-all text-sm font-medium"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="name@company.com"
            />
          </div>

          <div>
            <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5 ml-1">Security Credentials</label>
            <input 
              type="password" 
              required
              className="w-full px-5 py-4 bg-gray-50 border border-gray-100 rounded-2xl focus:bg-white focus:ring-2 focus:ring-red-600/10 focus:border-red-600 focus:outline-none transition-all text-sm font-medium"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter password"
            />
          </div>

          {isRegister && (
            <div>
              <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1.5 ml-1">Trade Role</label>
              <div className="grid grid-cols-2 gap-3 mt-2">
                <button 
                  type="button"
                  onClick={() => setRole(UserRole.BUYER)}
                  className={`py-4 rounded-2xl border text-[11px] font-black uppercase tracking-widest transition-all ${role === UserRole.BUYER ? 'bg-red-600 text-white border-red-600 shadow-lg shadow-red-100' : 'bg-gray-50 text-gray-400 border-gray-100 hover:bg-gray-100'}`}
                >
                  Global Buyer
                </button>
                <button 
                  type="button"
                  onClick={() => setRole(UserRole.SELLER)}
                  className={`py-4 rounded-2xl border text-[11px] font-black uppercase tracking-widest transition-all ${role === UserRole.SELLER ? 'bg-red-600 text-white border-red-600 shadow-lg shadow-red-100' : 'bg-gray-50 text-gray-400 border-gray-100 hover:bg-gray-100'}`}
                >
                  Direct Seller
                </button>
              </div>
            </div>
          )}

          <button 
            disabled={loading}
            type="submit"
            className="w-full py-5 bg-red-600 text-white font-bold rounded-2xl shadow-xl shadow-red-200 active:scale-[0.98] transition-all disabled:opacity-50 mt-6 text-sm uppercase tracking-widest"
          >
            {loading ? 'Validating...' : isRegister ? 'Establish Account' : 'Portal Login'}
          </button>
        </form>

        <div className="mt-8 text-center">
          <button 
            onClick={() => setIsRegister(!isRegister)}
            className="text-gray-500 text-xs font-medium hover:text-red-600 transition-colors"
          >
            {isRegister ? 'Already verified? ' : "New to the platform? "}
            <span className="font-bold border-b border-gray-200 ml-1">
              {isRegister ? 'Sign In' : 'Register Business'}
            </span>
          </button>
        </div>
      </div>
      
      <div className="p-8 bg-gray-50 flex items-center justify-center space-x-2 text-[10px] text-gray-400 font-bold uppercase tracking-[0.2em]">
        <ShieldCheck size={14} className="text-red-600" />
        <span>Secured by XB2BX Protocol</span>
      </div>
    </div>
  );
};

export default LoginScreen;
