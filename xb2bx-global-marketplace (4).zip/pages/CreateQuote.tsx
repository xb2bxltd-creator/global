
import React, { useState, useEffect } from 'react';
import { rfqApi, quoteApi, geminiApi } from '../api';
import { RFQ } from '../types';
import { 
  ArrowLeft, DollarSign, Zap, CheckCircle2, 
  Loader2, Sparkles, TrendingUp, ShieldCheck, 
  Target, Info
} from 'lucide-react';

interface CreateQuoteProps {
  rfqId: number;
  onBack: () => void;
  onSuccess: () => void;
}

const CreateQuote: React.FC<CreateQuoteProps> = ({ rfqId, onBack, onSuccess }) => {
  const [rfq, setRfq] = useState<RFQ | null>(null);
  const [price, setPrice] = useState('');
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [aiInsight, setAiInsight] = useState('');
  const [aiLoading, setAiLoading] = useState(false);
  const [done, setDone] = useState(false);

  useEffect(() => {
    const fetchRfq = async () => {
      try {
        const data = await rfqApi.getById(rfqId);
        setRfq(data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchRfq();
  }, [rfqId]);

  const handlePriceInsight = async () => {
    if (!price || !rfq) return;
    setAiLoading(true);
    try {
      const insight = await geminiApi.analyzeOpportunity(
        rfq.product, 
        `User entered price: $${price}. Volume: ${rfq.quantity}. Original Specs: ${rfq.specs}`
      );
      setAiInsight(insight);
    } catch (err) {
      console.error(err);
    } finally {
      setAiLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!price) return;
    setSubmitting(true);
    try {
      await quoteApi.create({ rfq_id: rfqId, price: Number(price) });
      setDone(true);
      setTimeout(() => onSuccess(), 1500);
    } catch (err) {
      alert("Submission failed. Protocol Error.");
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) return <div className="p-24 text-center animate-pulse text-[10px] font-black uppercase tracking-[0.3em] text-gray-300">Loading Opportunity...</div>;
  if (!rfq) return <div className="p-12 text-center text-red-600">RFQ Not Found</div>;

  if (done) {
    return (
      <div className="flex flex-col items-center justify-center py-32 text-center animate-in zoom-in-95 duration-500">
        <div className="w-24 h-24 bg-red-600 rounded-[2.5rem] flex items-center justify-center text-white mb-8 animate-bounce shadow-2xl shadow-red-200">
          <CheckCircle2 size={48} strokeWidth={3} />
        </div>
        <h2 className="text-3xl font-black italic uppercase tracking-tighter mb-4 text-gray-900">Bid Transmitted</h2>
        <p className="text-gray-400 text-[10px] font-black uppercase tracking-[0.2em] max-w-[220px] leading-loose">Commercial proposal submitted to buyer for final review.</p>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-in slide-in-from-bottom-8 duration-500 pb-20">
      <div className="flex items-center space-x-4">
        <button onClick={onBack} className="p-4 bg-white rounded-[1.5rem] border border-gray-100 shadow-sm text-gray-400 active:scale-90 transition-transform">
          <ArrowLeft size={20} />
        </button>
        <div>
          <h2 className="text-2xl font-black italic uppercase tracking-tighter">Draft Quote</h2>
          <p className="text-[9px] font-black text-red-600 uppercase tracking-[0.2em]">Procurement ID-{rfq.id}</p>
        </div>
      </div>

      {/* Opportunity Card */}
      <div className="bg-slate-900 p-8 rounded-[2.5rem] text-white shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8 opacity-10">
          <Target size={120} />
        </div>
        <div className="relative z-10 space-y-6">
          <div className="flex items-center space-x-2">
            <div className="p-1 bg-red-600 rounded-lg"><ShieldCheck size={12} /></div>
            <span className="text-[9px] font-black uppercase tracking-[0.3em] text-red-400">Verified Opportunity</span>
          </div>
          <div>
            <h3 className="text-2xl font-black italic uppercase tracking-tight leading-tight">{rfq.product}</h3>
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-2">Volume: {rfq.quantity.toLocaleString()} Units</p>
          </div>
          <div className="h-px bg-white/10 w-full" />
          <div className="flex items-center justify-between">
            <div>
              <p className="text-[8px] font-black uppercase tracking-widest text-slate-500 mb-1">Target Specs</p>
              <p className="text-[11px] font-medium text-slate-200 italic line-clamp-1">{rfq.specs}</p>
            </div>
            <div className="bg-emerald-500/10 border border-emerald-500/20 px-3 py-1.5 rounded-xl">
               <span className="text-[9px] font-black uppercase tracking-widest text-emerald-500">Escrow Ready</span>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-xl shadow-gray-200/20">
        <form onSubmit={handleSubmit} className="space-y-8">
          <div>
            <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-3 ml-1">Unit Price Proposal (USD)</label>
            <div className="relative">
              <div className="absolute left-6 top-1/2 -translate-y-1/2 text-gray-400 font-black text-xl italic">$</div>
              <input 
                type="number" 
                required
                step="0.01"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                onBlur={handlePriceInsight}
                className="w-full pl-12 pr-6 py-6 bg-gray-50 border border-transparent rounded-[1.5rem] focus:bg-white focus:border-red-600 focus:outline-none transition-all text-2xl font-black italic shadow-inner"
                placeholder="0.00"
              />
            </div>
          </div>

          {/* AI Feedback Section */}
          {(aiInsight || aiLoading) && (
            <div className="bg-red-50 p-6 rounded-[2rem] border border-red-100 relative group animate-in fade-in slide-in-from-top-4">
              <div className="flex items-center space-x-2 mb-4">
                <div className="p-1.5 bg-red-600 rounded-lg text-white">
                  {aiLoading ? <Loader2 size={14} className="animate-spin" /> : <Sparkles size={14} />}
                </div>
                <span className="text-[9px] font-black uppercase tracking-[0.2em] text-red-600">Gemini Price Check</span>
              </div>
              <p className="text-[11px] font-bold text-gray-700 leading-loose italic">
                {aiLoading ? 'Analyzing market benchmarks for this product category...' : aiInsight}
              </p>
            </div>
          )}

          <div className="bg-gray-50 p-6 rounded-[2rem] flex items-center space-x-4">
            <Info size={20} className="text-gray-400 flex-shrink-0" />
            <p className="text-[9px] font-bold uppercase tracking-widest text-gray-400 leading-relaxed">Quotes are legally binding once accepted by the buyer through the smart-contract layer.</p>
          </div>

          <button 
            disabled={submitting || aiLoading}
            type="submit"
            className="w-full py-6 bg-red-600 text-white font-black rounded-[1.5rem] shadow-2xl shadow-red-200 active:scale-95 transition-all disabled:opacity-50 text-[12px] uppercase tracking-[0.4em]"
          >
            {submitting ? 'Authenticating Bid...' : 'Submit Commercial Quote'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default CreateQuote;
