
import React, { useState } from 'react';
import { geminiApi, ResearchResult } from '../api';
import { 
  ArrowLeft, Search, Cpu, Sparkles, Loader2, 
  ExternalLink, TrendingUp, AlertCircle, ShieldInfo,
  Globe, BarChart3, Database, ChevronRight
} from 'lucide-react';

interface ResearchHubProps {
  onBack: () => void;
}

const ResearchHub: React.FC<ResearchHubProps> = ({ onBack }) => {
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<ResearchResult | null>(null);
  const [statusMsg, setStatusMsg] = useState('');

  const loadingMessages = [
    "Establishing neural link to global trade networks...",
    "Grounding research in verified market data...",
    "Analyzing supply chain volatility for 2024...",
    "Synthesizing price benchmarks and trends...",
    "Validating sources across corporate registries..."
  ];

  const handleResearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    setLoading(true);
    setResult(null);
    
    // Rotate messages
    let msgIdx = 0;
    const interval = setInterval(() => {
      setStatusMsg(loadingMessages[msgIdx % loadingMessages.length]);
      msgIdx++;
    }, 2500);

    try {
      const data = await geminiApi.researchProduct(query);
      setResult(data);
    } catch (err) {
      console.error(err);
      alert("Intelligence node timed out. Please retry.");
    } finally {
      clearInterval(interval);
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8 animate-in slide-in-from-bottom-8 duration-500 pb-24">
      <div className="flex items-center space-x-4">
        <button onClick={onBack} className="p-4 bg-white rounded-[1.5rem] border border-gray-100 shadow-sm text-gray-400 active:scale-90 transition-transform">
          <ArrowLeft size={20} />
        </button>
        <div>
          <h2 className="text-2xl font-black italic uppercase tracking-tighter">Market Intel</h2>
          <p className="text-[9px] font-black text-red-600 uppercase tracking-[0.2em]">Product Research Hub v4.0</p>
        </div>
      </div>

      {/* Intelligence Input */}
      <div className="bg-slate-900 p-8 rounded-[2.5rem] text-white shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8 opacity-10">
          <Database size={120} />
        </div>
        <div className="relative z-10 space-y-6">
          <div className="flex items-center space-x-2">
            <div className="p-1.5 bg-red-600 rounded-lg"><Cpu size={14} fill="currentColor" /></div>
            <span className="text-[10px] font-black uppercase tracking-[0.3em] text-red-400">Gemini 3 Pro Engine</span>
          </div>
          
          <form onSubmit={handleResearch} className="relative group">
            <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-red-600 transition-colors" size={24} />
            <input 
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Enter product, material or category..."
              className="w-full pl-16 pr-6 py-6 bg-white/5 border border-white/10 rounded-[1.5rem] focus:bg-white focus:text-slate-900 focus:outline-none transition-all text-lg font-bold italic shadow-inner"
            />
            <button 
              type="submit"
              disabled={loading || !query}
              className="absolute right-3 top-1/2 -translate-y-1/2 bg-red-600 text-white p-3.5 rounded-2xl active:scale-90 transition-transform disabled:opacity-50"
            >
              <TrendingUp size={20} />
            </button>
          </form>
          
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest text-center opacity-60">
            Real-time search grounding enabled for cross-border accuracy
          </p>
        </div>
      </div>

      {/* Results View */}
      {loading && (
        <div className="flex flex-col items-center justify-center py-20 text-center animate-pulse">
          <Loader2 size={48} className="text-red-600 animate-spin mb-6" />
          <p className="text-[11px] font-black uppercase tracking-[0.3em] text-gray-900 max-w-[240px] leading-loose">
            {statusMsg || "Initiating global query..."}
          </p>
        </div>
      )}

      {result && !loading && (
        <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4">
          {/* Main Analysis */}
          <div className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-sm relative overflow-hidden">
            <div className="flex items-center space-x-2 mb-8">
              <div className="p-2 bg-red-50 text-red-600 rounded-xl"><BarChart3 size={18} /></div>
              <h3 className="text-[10px] font-black text-gray-400 uppercase tracking-[0.3em]">Trade Intelligence Report</h3>
            </div>
            
            <div className="prose prose-red max-w-none text-gray-700 font-medium italic leading-relaxed text-sm whitespace-pre-line">
              {result.text}
            </div>
          </div>

          {/* Sources Section - MANDATORY AS PER GUIDELINES */}
          <div className="bg-slate-50 p-6 rounded-[2rem] border border-gray-200">
            <div className="flex items-center space-x-2 mb-6">
              <div className="p-2 bg-slate-900 text-white rounded-xl"><Globe size={16} /></div>
              <h3 className="text-[10px] font-black text-slate-900 uppercase tracking-[0.3em]">Verified Sources</h3>
            </div>
            
            <div className="grid grid-cols-1 gap-3">
              {result.sources.length > 0 ? result.sources.map((source, idx) => (
                <a 
                  key={idx}
                  href={source.uri}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-white p-4 rounded-2xl border border-gray-100 flex items-center justify-between group hover:border-red-600 transition-colors"
                >
                  <div className="flex items-center space-x-3 overflow-hidden">
                    <div className="p-2 bg-gray-50 text-gray-400 rounded-lg group-hover:text-red-600 group-hover:bg-red-50 transition-colors">
                      <ExternalLink size={14} />
                    </div>
                    <span className="text-[11px] font-bold text-gray-900 truncate uppercase tracking-widest">{source.title || "Market Asset"}</span>
                  </div>
                  {/* Fixed: Added missing ChevronRight component */}
                  <ChevronRight size={14} className="text-gray-300 group-hover:text-red-600" />
                </a>
              )) : (
                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest text-center py-4">Direct market data aggregated</p>
              )}
            </div>
          </div>

          {/* Disclaimer */}
          <div className="flex items-start space-x-4 px-6">
            <AlertCircle className="text-amber-500 shrink-0 mt-0.5" size={16} />
            <p className="text-[9px] font-bold text-gray-400 uppercase tracking-widest leading-loose">
              AI analysis is based on real-time web snapshots. Market conditions fluctuate rapidly. Verify technical specs with local customs authorities.
            </p>
          </div>
        </div>
      )}

      {/* Discovery Prompt */}
      {!loading && !result && (
        <div className="py-12 text-center opacity-30 px-12">
          <Sparkles className="mx-auto mb-6 text-slate-900" size={48} />
          <p className="text-[10px] font-black uppercase tracking-[0.4em] leading-relaxed">
            Enter a product or material to generate a global market intelligence report.
          </p>
        </div>
      )}
    </div>
  );
};

export default ResearchHub;
