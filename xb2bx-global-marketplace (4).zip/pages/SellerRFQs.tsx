
import React, { useEffect, useState } from 'react';
import { RFQ, Quote } from '../types';
import { rfqApi, quoteApi } from '../api';
import { 
  Search, Filter, Globe, ChevronRight, ChevronLeft, 
  Briefcase, Zap, TrendingUp,
  FileCheck, Plus
} from 'lucide-react';

interface SellerRFQsProps {
  onSelectRfq: (id: number) => void;
  onQuoteRfq: (id: number) => void;
}

const ITEMS_PER_PAGE = 20;

const SellerRFQs: React.FC<SellerRFQsProps> = ({ onSelectRfq, onQuoteRfq }) => {
  const [rfqs, setRfqs] = useState<RFQ[]>([]);
  const [sellerQuotes, setSellerQuotes] = useState<Quote[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);

  useEffect(() => {
    const fetch = async () => {
      try {
        const [rfqRes, quoteRes] = await Promise.all([
          rfqApi.getAll(),
          quoteApi.getSellerQuotes()
        ]);
        setRfqs(rfqRes);
        setSellerQuotes(quoteRes);
      } catch (err) { 
        console.error("Seller Portal Data Fetch Error:", err); 
      }
      finally { setLoading(false); }
    };
    fetch();
  }, []);

  // Reset to page 1 when searching
  useEffect(() => {
    setCurrentPage(1);
  }, [searchQuery]);

  const filteredRfqs = rfqs.filter(rfq => 
    rfq.product.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const totalPages = Math.ceil(filteredRfqs.length / ITEMS_PER_PAGE);
  const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
  const displayedRfqs = filteredRfqs.slice(startIndex, startIndex + ITEMS_PER_PAGE);

  const handlePrevPage = () => setCurrentPage(prev => Math.max(prev - 1, 1));
  const handleNextPage = () => setCurrentPage(prev => Math.min(prev + 1, totalPages));

  // Calculated metrics
  const activeCount = rfqs.length;
  const quoteCount = sellerQuotes.length;
  const conversionRate = activeCount > 0 ? Math.round((quoteCount / activeCount) * 100) : 0;

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-24">
      {/* 1. Global Search Input at the Top */}
      <div className="relative group pt-2">
        <Search className="absolute left-5 top-[60%] -translate-y-1/2 text-gray-400 group-focus-within:text-red-600 transition-colors" size={20} />
        <input 
          type="text" 
          placeholder="Search product opportunities..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full pl-14 pr-6 py-5 bg-white border border-gray-100 rounded-[2rem] focus:outline-none focus:ring-4 focus:ring-red-600/5 focus:border-red-600 shadow-sm font-bold text-sm transition-all"
        />
      </div>

      {/* 2. Dynamic Summary Header */}
      <section className="grid grid-cols-2 gap-3">
        <div className="col-span-2 bg-slate-900 p-6 rounded-[2.5rem] text-white shadow-xl relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-6 opacity-10 group-hover:rotate-12 transition-transform duration-700">
            <Zap size={80} fill="currentColor" />
          </div>
          <div className="relative z-10 flex flex-col h-full justify-between">
            <div className="flex justify-between items-start">
              <div>
                <div className="flex items-center space-x-2 mb-4">
                  <div className="p-1.5 bg-red-600 rounded-lg"><TrendingUp size={14} /></div>
                  <span className="text-[10px] font-black uppercase tracking-[0.3em] text-red-400">Seller Intelligence</span>
                </div>
                <h2 className="text-2xl font-black italic tracking-tighter uppercase leading-none mb-1">Market Velocity</h2>
                <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Cross-border demand is scaling.</p>
              </div>
              <button className="bg-red-600 p-3 rounded-2xl shadow-lg active:scale-90 transition-transform">
                <Plus size={20} />
              </button>
            </div>
            <div className="mt-8 flex items-center space-x-4">
              <div className="flex-1 bg-white/5 border border-white/10 rounded-2xl p-4">
                <p className="text-[8px] font-black uppercase tracking-widest text-slate-500 mb-1">Global Leads</p>
                <p className="text-2xl font-black italic tracking-tighter">{activeCount}</p>
              </div>
              <div className="flex-1 bg-white/5 border border-white/10 rounded-2xl p-4">
                <p className="text-[8px] font-black uppercase tracking-widest text-slate-500 mb-1">Engagement</p>
                <p className="text-2xl font-black italic tracking-tighter">{conversionRate}%</p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white p-5 rounded-[2.2rem] border border-gray-100 shadow-sm flex flex-col justify-between">
          <div className="flex justify-between items-start">
            <div className="p-2.5 bg-red-50 text-red-600 rounded-xl"><FileCheck size={18} /></div>
            <span className="text-[8px] font-black text-emerald-500 bg-emerald-50 px-2 py-1 rounded-lg">ACTIVE</span>
          </div>
          <div className="mt-4">
            <p className="text-gray-400 text-[9px] font-black uppercase tracking-widest mb-1">My Proposals</p>
            <p className="text-3xl font-black text-gray-900 italic tracking-tighter">{quoteCount}</p>
          </div>
        </div>

        <div className="bg-white p-5 rounded-[2.2rem] border border-gray-100 shadow-sm flex flex-col justify-between">
          <div className="flex justify-between items-start">
            <div className="p-2.5 bg-blue-50 text-blue-600 rounded-xl"><Briefcase size={18} /></div>
            <span className="text-[8px] font-black text-blue-500 bg-blue-50 px-2 py-1 rounded-lg">MATCHED</span>
          </div>
          <div className="mt-4">
            <p className="text-gray-400 text-[9px] font-black uppercase tracking-widest mb-1">Opportunities</p>
            <p className="text-3xl font-black text-gray-900 italic tracking-tighter">{filteredRfqs.length}</p>
          </div>
        </div>
      </section>

      {/* 3. Control Bar */}
      <div className="flex justify-between items-end px-1 pt-2">
        <div>
          <h2 className="text-2xl font-black italic uppercase tracking-tighter">Opportunities</h2>
          <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest mt-1">
            Browse verified procurement requests
          </p>
        </div>
        <button className="p-3 bg-white border border-gray-100 rounded-2xl text-gray-500 shadow-sm active:scale-95 transition-transform">
          <Filter size={18} />
        </button>
      </div>

      {/* 4. Opportunity List */}
      <div className="space-y-4">
        {loading ? (
          [1,2,3,4].map(n => <div key={n} className="h-32 bg-white border border-gray-100 rounded-[2.5rem] animate-pulse" />)
        ) : filteredRfqs.length === 0 ? (
          <div className="bg-white p-16 rounded-[3rem] border border-gray-100 text-center shadow-sm">
            <p className="text-gray-900 font-black text-lg mb-2 uppercase italic tracking-tighter">Zero results</p>
            <p className="text-gray-400 text-[9px] font-bold uppercase tracking-widest">Adjust your filters to see more leads.</p>
          </div>
        ) : (
          <>
            {displayedRfqs.map(rfq => {
              const hasQuoted = sellerQuotes.some(q => q.rfq_id === rfq.id);
              return (
                <div 
                  key={rfq.id}
                  onClick={() => onSelectRfq(rfq.id)}
                  className="bg-white p-5 rounded-[2.5rem] border border-gray-100 shadow-sm active:scale-[0.98] transition-all hover:shadow-md cursor-pointer group relative overflow-hidden"
                >
                  {hasQuoted && (
                    <div className="absolute top-0 right-0">
                       <div className="bg-emerald-500 text-white text-[7px] font-black uppercase tracking-widest px-4 py-1 rotate-45 translate-x-3 translate-y-2 shadow-sm">Bidded</div>
                    </div>
                  )}
                  
                  <div className="flex justify-between items-start mb-4">
                    <div className="flex items-center space-x-2">
                      <div className="w-8 h-8 bg-red-50 rounded-lg flex items-center justify-center text-red-600 group-hover:bg-red-600 group-hover:text-white transition-colors">
                        <Globe size={16} />
                      </div>
                      <span className="text-[9px] font-black text-gray-400 uppercase tracking-[0.2em]">Verified Hub</span>
                    </div>
                    {!hasQuoted && <span className="text-[9px] font-black text-red-600 bg-red-50 px-2.5 py-1.5 rounded-lg tracking-widest uppercase">New Lead</span>}
                  </div>

                  <h3 className="font-black text-lg mb-1 italic tracking-tighter uppercase">{rfq.product}</h3>
                  <p className="text-gray-500 text-xs line-clamp-2 mb-4 font-medium italic opacity-70">
                    {rfq.specs || "Technical procurement requirements finalized. Open for commercial proposals."}
                  </p>
                  
                  <div className="flex justify-between items-center pt-4 border-t border-gray-50">
                    <div className="flex items-center space-x-5">
                      <div>
                        <p className="text-[8px] font-black text-gray-400 uppercase tracking-widest mb-0.5">Volume</p>
                        <p className="text-xs font-black italic tracking-tighter text-gray-900">{rfq.quantity.toLocaleString()} UNITS</p>
                      </div>
                      <div>
                        <p className="text-[8px] font-black text-gray-400 uppercase tracking-widest mb-0.5">Payment</p>
                        <p className="text-xs font-black italic tracking-tighter text-emerald-600">ESCROWED</p>
                      </div>
                    </div>
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        if (hasQuoted) onSelectRfq(rfq.id);
                        else onQuoteRfq(rfq.id);
                      }}
                      className={`flex items-center space-x-1.5 font-black text-[10px] uppercase tracking-widest px-4 py-2 rounded-full border transition-all ${hasQuoted ? 'bg-gray-50 text-gray-400 border-gray-100' : 'text-white bg-red-600 border-red-600 shadow-lg shadow-red-100 active:scale-95'}`}
                    >
                      <span>{hasQuoted ? 'Edit Bid' : 'Quote Now'}</span>
                      <ChevronRight size={14} />
                    </button>
                  </div>
                </div>
              );
            })}

            {/* Pagination Controls */}
            {totalPages > 1 && (
              <div className="flex items-center justify-between pt-6 px-2">
                <button 
                  onClick={handlePrevPage}
                  disabled={currentPage === 1}
                  className="p-3 bg-white border border-gray-100 rounded-2xl text-gray-400 shadow-sm disabled:opacity-30 disabled:shadow-none active:scale-90 transition-all"
                >
                  <ChevronLeft size={20} />
                </button>
                
                <div className="flex flex-col items-center">
                  <span className="text-[10px] font-black text-gray-900 uppercase tracking-[0.3em]">
                    Page {currentPage} of {totalPages}
                  </span>
                  <div className="flex space-x-1 mt-2">
                    {Array.from({ length: Math.min(5, totalPages) }).map((_, i) => {
                      let pageNum = currentPage;
                      if (currentPage < 3) pageNum = i + 1;
                      else if (currentPage > totalPages - 2) pageNum = totalPages - 4 + i;
                      else pageNum = currentPage - 2 + i;

                      if (pageNum <= 0 || pageNum > totalPages) return null;

                      return (
                        <div 
                          key={pageNum}
                          className={`w-1.5 h-1.5 rounded-full transition-all duration-300 ${currentPage === pageNum ? 'bg-red-600 w-4' : 'bg-gray-200'}`}
                        />
                      );
                    })}
                  </div>
                </div>

                <button 
                  onClick={handleNextPage}
                  disabled={currentPage === totalPages}
                  className="p-3 bg-white border border-gray-100 rounded-2xl text-gray-400 shadow-sm disabled:opacity-30 disabled:shadow-none active:scale-90 transition-all"
                >
                  <ChevronRight size={20} />
                </button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default SellerRFQs;
