
import React, { useEffect, useState } from 'react';
import { RFQ, User, UserRole, Quote } from '../types';
import { rfqApi, quoteApi, geminiApi } from '../api';
import { 
  Package, Bell, ChevronRight, Search, Globe, 
  TrendingUp, Sparkles, Zap, ArrowUpRight, ShieldCheck,
  LayoutGrid, Factory, Shirt, Zap as Electric, Construction,
  Cpu, Activity
} from 'lucide-react';

interface DashboardProps {
  user: User;
  onSelectRfq: (id: number) => void;
  onAction: () => void;
  onIntel: () => void;
}

const CATEGORIES = [
  { name: 'Industrial', icon: Factory, color: 'text-blue-600', bg: 'bg-blue-50' },
  { name: 'Apparel', icon: Shirt, color: 'text-pink-600', bg: 'bg-pink-50' },
  { name: 'Energy', icon: Electric, color: 'text-amber-600', bg: 'bg-amber-50' },
  { name: 'Construction', icon: Construction, color: 'text-orange-600', bg: 'bg-orange-50' },
  { name: 'Tech', icon: LayoutGrid, color: 'text-indigo-600', bg: 'bg-indigo-50' },
];

const Dashboard: React.FC<DashboardProps> = ({ user, onSelectRfq, onAction, onIntel }) => {
  const [rfqs, setRfqs] = useState<RFQ[]>([]);
  const [quotes, setQuotes] = useState<Quote[]>([]);
  const [aiInsight, setAiInsight] = useState<string>('');
  const [smartMatches, setSmartMatches] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const rfqRes = await rfqApi.getAll();
        setRfqs(rfqRes);
        
        if (user.role === UserRole.SELLER) {
          const myQuotes = await quoteApi.getSellerQuotes();
          setQuotes(myQuotes);
        }

        const [insight, matches] = await Promise.all([
          geminiApi.getMarketInsights(user.role, rfqRes.length),
          geminiApi.getSmartMatches(user.role, ['solar', 'lithium', 'textiles'])
        ]);
        setAiInsight(insight);
        setSmartMatches(matches);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [user.role]);

  return (
    <div className="space-y-8 pb-12 animate-in fade-in slide-in-from-bottom-4 duration-700">
      {/* Search & Header */}
      <div className="space-y-6">
        <header className="flex justify-between items-center pt-2">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-red-600 rounded-2xl flex items-center justify-center text-white shadow-xl rotate-3">
              <Globe size={24} />
            </div>
            <div>
              <h1 className="text-2xl font-black italic tracking-tighter">XB2BX</h1>
              <p className="text-[8px] font-black uppercase tracking-[0.2em] text-gray-400">Global Trade Hub</p>
            </div>
          </div>
          <button className="relative p-3 bg-white rounded-2xl border border-gray-100 text-gray-400 shadow-sm active:scale-90 transition-transform">
            <Bell size={20} />
            <span className="absolute top-3 right-3 w-2 h-2 bg-red-600 border-2 border-white rounded-full"></span>
          </button>
        </header>

        <div onClick={onIntel} className="relative group cursor-pointer">
          <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-red-600 transition-colors" size={20} />
          <div className="w-full pl-14 pr-6 py-5 bg-white border border-gray-100 rounded-[2rem] text-gray-400 text-sm font-medium shadow-sm flex items-center">
            Research products or suppliers...
          </div>
          <div className="absolute right-4 top-1/2 -translate-y-1/2 bg-red-50 text-red-600 px-3 py-1 rounded-xl text-[8px] font-black uppercase tracking-widest">
            AI Powered
          </div>
        </div>
      </div>

      {/* AI Recommendation Section */}
      <div className="bg-slate-900 p-6 rounded-[2.5rem] text-white shadow-2xl relative overflow-hidden group">
        <div className="absolute top-0 right-0 p-6 opacity-10 group-hover:opacity-20 transition-opacity">
          <Sparkles size={80} />
        </div>
        <div className="relative z-10 space-y-4">
          <div className="flex justify-between items-start">
            <div className="flex items-center space-x-2">
              <div className="p-1.5 bg-red-600 rounded-lg"><Zap size={14} fill="currentColor" /></div>
              <span className="text-[10px] font-black uppercase tracking-[0.3em] text-red-400">SmartMatch Engine</span>
            </div>
            <button onClick={onIntel} className="p-2 bg-white/5 rounded-xl text-white/40 hover:text-white transition-colors">
              <Cpu size={14} />
            </button>
          </div>
          <p className="text-sm font-bold leading-relaxed pr-8 italic">{aiInsight || "Calibrating market matches..."}</p>
          <div className="flex flex-wrap gap-2">
            {smartMatches.map(tag => (
              <span key={tag} className="text-[8px] font-black uppercase tracking-widest bg-white/10 px-3 py-1.5 rounded-full border border-white/5">
                {tag.trim()}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Market Intel Entry Card */}
      <div 
        onClick={onIntel}
        className="bg-red-600 p-6 rounded-[2.2rem] text-white flex items-center justify-between group cursor-pointer shadow-xl shadow-red-100 active:scale-95 transition-all overflow-hidden relative"
      >
        <div className="absolute -right-4 -bottom-4 text-white/10 rotate-12 group-hover:scale-125 transition-transform duration-1000">
          <Activity size={120} />
        </div>
        <div className="relative z-10">
          <p className="text-[9px] font-black uppercase tracking-[0.2em] opacity-80 mb-1">Global Intelligence</p>
          <h3 className="text-xl font-black italic uppercase tracking-tighter">Product Research Hub</h3>
          <p className="text-[10px] font-bold opacity-60 mt-1 uppercase tracking-widest">Real-time market tracking enabled</p>
        </div>
        <div className="relative z-10 bg-white/20 p-4 rounded-2xl backdrop-blur-sm group-hover:bg-white group-hover:text-red-600 transition-colors">
          <ArrowUpRight size={20} />
        </div>
      </div>

      {/* Category Picker (Discovery Layer) */}
      <div className="overflow-x-auto no-scrollbar -mx-4 px-4 py-2 flex space-x-4">
        {CATEGORIES.map((cat) => (
          <button key={cat.name} className="flex flex-col items-center space-y-2 min-w-[70px] group">
            <div className={`${cat.bg} p-4 rounded-3xl transition-all group-active:scale-90 border border-transparent hover:border-red-100 shadow-sm`}>
              <cat.icon className={`${cat.color}`} size={24} />
            </div>
            <span className="text-[9px] font-black uppercase tracking-widest text-gray-400">{cat.name}</span>
          </button>
        ))}
      </div>

      {/* Bento Grid Metrics */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white p-6 rounded-[2.2rem] border border-gray-100 shadow-sm relative group">
          <div className="absolute top-4 right-4 text-emerald-500 bg-emerald-50 p-2 rounded-xl"><TrendingUp size={16} /></div>
          <p className="text-gray-400 text-[10px] font-black uppercase tracking-widest mb-1">Market Vol.</p>
          <p className="text-4xl font-black text-gray-900 italic tracking-tighter">{rfqs.length}</p>
          <div className="mt-2 text-[8px] font-bold text-emerald-600 uppercase tracking-widest">+12.5% this week</div>
        </div>

        <div className="bg-white p-6 rounded-[2.2rem] border border-gray-100 shadow-sm relative group overflow-hidden">
          <div className="absolute top-4 right-4 text-red-600 bg-red-50 p-2 rounded-xl"><ShieldCheck size={16} /></div>
          <p className="text-gray-400 text-[10px] font-black uppercase tracking-widest mb-1">Assurance</p>
          <p className="text-4xl font-black text-gray-900 italic tracking-tighter">100%</p>
          <div className="mt-2 text-[8px] font-bold text-red-600 uppercase tracking-widest">Vault Protected</div>
        </div>
      </div>

      {/* Trending RFQs / Marketplace */}
      <div className="space-y-4">
        <div className="flex justify-between items-end px-1">
          <div>
            <h3 className="font-black text-[11px] uppercase tracking-[0.2em] text-gray-400">Live Trade Stream</h3>
            <div className="h-1 w-8 bg-red-600 rounded-full mt-1"></div>
          </div>
          <button onClick={onAction} className="text-red-600 text-[9px] font-black uppercase tracking-[0.2em] flex items-center group">
            Global Board <ArrowUpRight size={14} className="ml-1 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
          </button>
        </div>

        {loading ? (
          <div className="space-y-4">
            {[1,2,3].map(n => <div key={n} className="h-32 bg-white border border-gray-100 rounded-[2.5rem] animate-pulse" />)}
          </div>
        ) : (
          rfqs.map(rfq => (
            <div 
              key={rfq.id} 
              onClick={() => onSelectRfq(rfq.id)}
              className="bg-white p-4 rounded-[2.5rem] border border-gray-100 flex items-center justify-between shadow-sm cursor-pointer hover:shadow-md active:scale-95 transition-all group"
            >
              <div className="flex items-center space-x-5">
                <div className="w-20 h-20 bg-slate-50 rounded-3xl flex items-center justify-center border border-gray-100 relative overflow-hidden shadow-inner">
                   {rfq.image_url ? (
                     <img src={rfq.image_url} alt="" className="w-full h-full object-cover group-hover:scale-110 transition-transform" />
                   ) : (
                     <Package size={28} className="text-gray-200" />
                   )}
                   <div className="absolute top-2 left-2 bg-red-600 p-1 rounded-lg text-white shadow-lg"><ShieldCheck size={10} /></div>
                </div>
                <div>
                  <h4 className="font-black text-sm text-gray-900 line-clamp-1 uppercase italic tracking-tight">{rfq.product}</h4>
                  <div className="flex items-center space-x-2 mt-2">
                    <span className="text-[9px] font-black text-emerald-600 bg-emerald-50 px-2 py-1 rounded-lg uppercase tracking-widest">{rfq.quantity.toLocaleString()} UNITS</span>
                    <span className="text-[8px] font-black text-gray-300 uppercase tracking-[0.2em]">Verified Hub</span>
                  </div>
                </div>
              </div>
              <div className="p-3 bg-gray-50 rounded-2xl text-gray-300 group-hover:text-red-600 transition-colors">
                <ChevronRight size={18} />
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default Dashboard;
