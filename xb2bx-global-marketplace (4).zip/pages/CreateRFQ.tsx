
import React, { useState } from 'react';
import { rfqApi, uploadApi, geminiApi } from '../api';
import { 
  ArrowLeft, Package, ImageIcon, CheckCircle2, 
  Loader2, Info, Sparkles, Wand2, Palette
} from 'lucide-react';

interface CreateRFQProps {
  onBack: () => void;
  onSuccess: () => void;
}

const CreateRFQ: React.FC<CreateRFQProps> = ({ onBack, onSuccess }) => {
  const [product, setProduct] = useState('');
  const [quantity, setQuantity] = useState('');
  const [specs, setSpecs] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);
  const [imgAiLoading, setImgAiLoading] = useState(false);
  const [done, setDone] = useState(false);

  const handleAiAssist = async () => {
    if (!product) {
      alert("Please enter a product name first.");
      return;
    }
    setAiLoading(true);
    try {
      const generated = await geminiApi.generateSpecs(product);
      setSpecs(generated);
    } catch (err) {
      console.error("AI Assist failed", err);
    } finally {
      setAiLoading(false);
    }
  };

  const handleGenerateImage = async () => {
    if (!product) {
      alert("Specify a product to generate a render.");
      return;
    }
    setImgAiLoading(true);
    try {
      const url = await geminiApi.generateProductImage(product);
      if (url) setImageUrl(url);
    } catch (err) {
      console.error("Image gen failed", err);
    } finally {
      setImgAiLoading(false);
    }
  };

  const handleImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setLoading(true);
      try {
        const url = await uploadApi.uploadImage(file);
        setImageUrl(url);
      } catch (err) {
        console.error("Upload failed", err);
      } finally {
        setLoading(false);
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!product || !quantity) return;
    
    setLoading(true);
    try {
      await rfqApi.create({ 
        product, 
        quantity: Number(quantity), 
        specs,
        image_url: imageUrl,
        category: 'Tech' // Default category for standard
      });
      setDone(true);
      setTimeout(() => onSuccess(), 1500);
    } catch (err) {
      alert("Gateway Error");
      setLoading(false);
    }
  };

  if (done) {
    return (
      <div className="flex flex-col items-center justify-center py-32 text-center animate-in zoom-in-95 duration-500">
        <div className="w-24 h-24 bg-red-600 rounded-[2.5rem] flex items-center justify-center text-white mb-8 animate-bounce shadow-2xl shadow-red-200">
          <CheckCircle2 size={48} strokeWidth={3} />
        </div>
        <h2 className="text-3xl font-black italic uppercase tracking-tighter mb-4 text-gray-900">RFQ Logged</h2>
        <p className="text-gray-400 text-[10px] font-black uppercase tracking-[0.2em] max-w-[220px] leading-loose">Transmitting your requirements to global verified sellers.</p>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-in slide-in-from-bottom-8 duration-500 pb-20">
      <div className="flex items-center space-x-4">
        <button onClick={onBack} className="p-4 bg-white rounded-[1.5rem] border border-gray-100 shadow-sm text-gray-400 active:scale-90 transition-transform">
          <ArrowLeft size={20} />
        </button>
        <div>
          <h2 className="text-2xl font-black italic uppercase tracking-tighter">Initialize RFQ</h2>
          <p className="text-[9px] font-black text-red-600 uppercase tracking-[0.2em]">Step 1 of 2: Specifications</p>
        </div>
      </div>

      <div className="bg-white p-6 rounded-[2.5rem] border border-gray-100 shadow-xl shadow-gray-200/20">
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Reference Image Section with AI Generation */}
          <div className="relative group overflow-hidden bg-slate-900 rounded-[2rem] aspect-video flex flex-col items-center justify-center border-4 border-white shadow-lg">
            {imageUrl ? (
              <img src={imageUrl} alt="Product" className="absolute inset-0 w-full h-full object-cover" />
            ) : (
              <div className="flex flex-col items-center text-gray-500">
                {loading || imgAiLoading ? <Loader2 size={32} className="mb-2 animate-spin text-red-600" /> : <ImageIcon size={32} className="text-gray-700" />}
                <span className="text-[9px] font-black uppercase tracking-widest mt-2">
                  {loading ? 'Storing Asset...' : imgAiLoading ? 'Gemini is Rendering...' : 'Product Reference Image'}
                </span>
              </div>
            )}
            <input 
              type="file" 
              accept="image/*"
              onChange={handleImageChange}
              disabled={loading || imgAiLoading}
              className="absolute inset-0 opacity-0 cursor-pointer z-10"
            />
            
            {/* AI Image Generation FAB */}
            {!imageUrl && !loading && !imgAiLoading && product && (
              <button
                type="button"
                onClick={handleGenerateImage}
                className="absolute bottom-4 right-4 bg-red-600 text-white p-3 rounded-2xl shadow-xl flex items-center space-x-2 active:scale-90 transition-all z-20 group-hover:translate-y-0 translate-y-2 opacity-0 group-hover:opacity-100"
              >
                <Palette size={16} />
                <span className="text-[9px] font-black uppercase tracking-widest">AI Render</span>
              </button>
            )}
          </div>

          <div className="space-y-5">
            <div>
              <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 ml-1">Marketplace Description</label>
              <div className="relative">
                <Package className="absolute left-5 top-1/2 -translate-y-1/2 text-gray-300" size={20} />
                <input 
                  type="text" 
                  required
                  value={product}
                  onChange={(e) => setProduct(e.target.value)}
                  className="w-full pl-14 pr-6 py-5 bg-gray-50 border border-transparent rounded-[1.5rem] focus:bg-white focus:border-red-600 focus:outline-none transition-all text-sm font-bold shadow-inner"
                  placeholder="e.g. Solar Photovoltaic Modules"
                />
              </div>
            </div>

            <div className="flex space-x-4">
              <div className="flex-1">
                <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 ml-1">Target Quantity</label>
                <input 
                  type="number" 
                  required
                  value={quantity}
                  onChange={(e) => setQuantity(e.target.value)}
                  className="w-full px-6 py-5 bg-gray-50 border border-transparent rounded-[1.5rem] focus:bg-white focus:border-red-600 focus:outline-none transition-all text-sm font-black italic shadow-inner"
                  placeholder="Quantity"
                />
              </div>
              <div className="w-1/3">
                <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 ml-1">Unit</label>
                <select className="w-full px-4 py-5 bg-gray-50 border border-transparent rounded-[1.5rem] text-sm font-black uppercase tracking-widest">
                  <option>PCS</option>
                  <option>SETS</option>
                  <option>KG</option>
                  <option>TONS</option>
                </select>
              </div>
            </div>

            <div className="relative">
              <div className="flex justify-between items-center mb-2 px-1">
                <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest">Technical Specifications</label>
                <button 
                  type="button"
                  onClick={handleAiAssist}
                  disabled={aiLoading}
                  className="flex items-center space-x-1 text-[10px] font-black text-red-600 uppercase tracking-widest bg-red-50 px-3 py-1.5 rounded-full border border-red-100 active:scale-95 transition-all disabled:opacity-50"
                >
                  {aiLoading ? <Loader2 size={12} className="animate-spin" /> : <Wand2 size={12} />}
                  <span>AI Assist</span>
                </button>
              </div>
              <textarea 
                rows={5}
                value={specs}
                onChange={(e) => setSpecs(e.target.value)}
                className="w-full px-6 py-5 bg-gray-50 border border-transparent rounded-[1.5rem] focus:bg-white focus:border-red-600 focus:outline-none transition-all text-sm font-medium shadow-inner"
                placeholder="Describe material, grade, quality standards..."
              ></textarea>
              {aiLoading && (
                <div className="absolute inset-0 bg-white/60 backdrop-blur-[2px] rounded-[1.5rem] flex items-center justify-center">
                  <div className="flex flex-col items-center">
                    <Sparkles className="text-red-600 animate-pulse mb-2" size={32} />
                    <span className="text-[9px] font-black text-gray-600 uppercase tracking-widest">Gemini is writing...</span>
                  </div>
                </div>
              )}
            </div>
          </div>

          <button 
            disabled={loading || aiLoading || imgAiLoading}
            type="submit"
            className="w-full py-6 bg-slate-900 text-white font-black rounded-[1.5rem] shadow-2xl active:scale-95 transition-all disabled:opacity-50 text-[11px] uppercase tracking-[0.4em]"
          >
            {loading ? 'Transmitting...' : 'Post RFQ to Global Market'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default CreateRFQ;
