
import React from 'react';
import { FileText, User, PlusCircle, LayoutGrid, Cpu } from 'lucide-react';
import { UserRole } from '../types';

interface BottomNavProps {
  currentView: string;
  setCurrentView: (view: any) => void;
  role: UserRole;
}

const BottomNav: React.FC<BottomNavProps> = ({ currentView, setCurrentView, role }) => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-xl border-t border-gray-100 px-8 py-4 flex justify-between items-center shadow-[0_-10px_30px_rgba(0,0,0,0.03)] safe-bottom max-w-lg mx-auto z-50 rounded-t-[2.5rem]">
      <NavBtn 
        active={currentView === 'home'} 
        onClick={() => setCurrentView('home')} 
        icon={<LayoutGrid size={24} strokeWidth={currentView === 'home' ? 2.5 : 1.5} />} 
        label="Portal" 
      />
      <NavBtn 
        active={currentView === 'rfqs'} 
        onClick={() => setCurrentView('rfqs')} 
        icon={<FileText size={24} strokeWidth={currentView === 'rfqs' ? 2.5 : 1.5} />} 
        label={role === UserRole.BUYER ? 'Sourcing' : 'Trade'} 
      />
      
      {role === UserRole.BUYER && (
        <button 
          onClick={() => setCurrentView('create-rfq')}
          className="relative -mt-12 group"
        >
          <div className="bg-red-600 p-5 rounded-[2rem] text-white shadow-2xl shadow-red-200 transition-all duration-300 group-active:scale-90 group-hover:shadow-red-300">
            <PlusCircle size={32} />
          </div>
          <span className="absolute -bottom-7 left-1/2 -translate-x-1/2 text-[9px] font-black text-red-600 uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity">Post RFQ</span>
        </button>
      )}

      <NavBtn 
        active={currentView === 'intel'} 
        onClick={() => setCurrentView('intel')} 
        icon={<Cpu size={24} strokeWidth={currentView === 'intel' ? 2.5 : 1.5} />} 
        label="Intel" 
      />
      <NavBtn 
        active={currentView === 'profile'} 
        onClick={() => setCurrentView('profile')} 
        icon={<User size={24} strokeWidth={currentView === 'profile' ? 2.5 : 1.5} />} 
        label="Account" 
      />
    </nav>
  );
};

const NavBtn: React.FC<{ active: boolean; onClick: () => void; icon: React.ReactNode; label: string }> = ({ active, onClick, icon, label }) => (
  <button 
    onClick={onClick}
    className={`flex flex-col items-center space-y-1.5 transition-all duration-300 ${active ? 'text-red-600' : 'text-gray-300 hover:text-gray-400'}`}
  >
    <div className={`transition-transform duration-300 ${active ? 'scale-110' : 'scale-100'}`}>
      {icon}
    </div>
    <span className={`text-[9px] font-black uppercase tracking-widest transition-opacity ${active ? 'opacity-100' : 'opacity-60'}`}>{label}</span>
  </button>
);

export default BottomNav;
