
import React from 'react';

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return (
    <div className="bg-gray-50 min-h-screen flex flex-col">
      <div className="flex-1 overflow-y-auto">
        {children}
      </div>
    </div>
  );
};
